/* ============================================================
   LAURE AURA — toutes les infos du site sont ICI.

   Ajouter un produit :
     1. mettez la photo dans le dossier  images/
     2. copiez une ligne { id: ... } ci-dessous, collez-la,
        changez l'id (numéro unique), le nom, le prix et la photo.
   ============================================================ */

window.SITE = {
  name: 'Laure Aura',
  logo: 'images/logo-512.png',
  whatsapp: '237694927173',          // numéro qui reçoit commandes, RDV, avis
  phone: '+237 694 927 173',
  address: 'Douala, Cameroun',
  email: '',
  currency: 'FCFA',
  tagline: { fr: "L'élégance qui vous ressemble", en: 'Elegance that looks like you' },
  about: { fr: "Laure Aura est un salon de beauté et une boutique de mode à Douala.\nNous coiffons, nous sublimons vos ongles et nous sélectionnons des pièces qui font la différence.",
           en: "Laure Aura is a beauty salon and fashion boutique in Douala.\nWe style hair, perfect nails and hand-pick pieces that stand out." },
  hours: { fr: "Lun – Sam : 8h – 20h\nDim : 13h – 19h", en: "Mon – Sat: 8am – 8pm\nSun: 1pm – 7pm" },
  socials: { instagram: '', facebook: '', tiktok: '' },   // collez vos liens complets

  // icon : shirt, crown, wand-sparkles, scissors, hand, shopping-bag, footprints, package, gem, sparkles, palette
  // booking: true  = la catégorie apparaît dans la page RDV
  categories: [
    { id: 'robes', fr: "Robes", en: "Dresses", icon: 'shirt' },
    { id: 'tailleurs', fr: "Tailleurs & Manteaux", en: "Suits & Coats", icon: 'crown' },
    { id: 'perruques', fr: "Perruques", en: "Wigs", icon: 'wand-sparkles' },
    { id: 'coiffures', fr: "Coiffures", en: "Hairstyles", icon: 'scissors', booking: true },
    { id: 'ongles', fr: "Ongles", en: "Nails", icon: 'hand', booking: true },
    { id: 'sacs', fr: "Sacs", en: "Bags", icon: 'shopping-bag' },
    { id: 'chaussures', fr: "Chaussures", en: "Shoes", icon: 'footprints' },
    { id: 'packs', fr: "Packs", en: "Packs", icon: 'package' },
  ],

  // for : 'women' | 'men' | 'unisex'     badge : 'new' | 'best' | 'promo'
  // old : ancien prix (barré)     featured: true = coup de cœur sur l'accueil
  products: [
    { id: 1, cat: 'robes', fr: "Robe bustier à volants", en: "Ruffle bustier dress", price: 35000, img: 'images/p0709.jpg', for: 'women', badge: 'new', featured: true, sizes: "S, M, L" },
    { id: 2, cat: 'robes', fr: "Robe corset sequins bordeaux", en: "Burgundy sequin corset dress", price: 42000, old: 48000, img: 'images/p0708.jpg', for: 'women', badge: 'promo', featured: true, sizes: "S, M, L" },
    { id: 3, cat: 'robes', fr: "Robe longue drapée jaune", en: "Yellow draped gown", price: 55000, img: 'images/p0707.jpg', for: 'women', featured: true, sizes: "S, M, L" },
    { id: 4, cat: 'robes', fr: "Robe épaules nues rose", en: "Pink off-shoulder gown", price: 48000, img: 'images/p0706.jpg', for: 'women', badge: 'best', sizes: "S, M, L, XL" },
    { id: 5, cat: 'robes', fr: "Robe dos-nu crème", en: "Cream halter midi dress", price: 25000, img: 'images/p0705.jpg', for: 'women', sizes: "S, M, L" },
    { id: 6, cat: 'robes', fr: "Robe rétro rouge", en: "Red retro midi dress", price: 30000, img: 'images/p0704.jpg', for: 'women', badge: 'best', featured: true, sizes: "S, M, L" },
    { id: 7, cat: 'robes', fr: "Robe brodée fleurs rouges", en: "Embroidered floral dress", price: 38000, img: 'images/p0703.jpg', for: 'women', badge: 'new', sizes: "S, M" },
    { id: 8, cat: 'robes', fr: "Robe blanche plissée", en: "White pleated dress", price: 27000, img: 'images/p0702.jpg', for: 'women', sizes: "S, M, L" },
    { id: 9, cat: 'robes', fr: "Robe néon à volants", en: "Neon ruffle dress", price: 32000, old: 36000, img: 'images/p0701.jpg', for: 'women', badge: 'promo', sizes: "S, M, L" },
    { id: 10, cat: 'robes', fr: "Robe asymétrique rose poudré", en: "Blush one-shoulder dress", price: 33000, img: 'images/p0700.jpg', for: 'women', sizes: "S, M, L" },
    { id: 11, cat: 'robes', fr: "Robe dos-nu rose", en: "Pink halter dress", price: 28000, img: 'images/p0699.jpg', for: 'women', sizes: "S, M, L" },
    { id: 12, cat: 'robes', fr: "Robe chemise chocolat", en: "Chocolate shirt dress", price: 36000, img: 'images/p0696.jpg', for: 'women', sizes: "S, M, L, XL" },
    { id: 13, cat: 'tailleurs', fr: "Tailleur jupe cintré", en: "Fitted skirt suit", price: 60000, img: 'images/p7909.jpg', for: 'women', badge: 'new', featured: true, sizes: "S, M, L" },
    { id: 14, cat: 'tailleurs', fr: "Manteau long bordeaux", en: "Long burgundy coat", price: 75000, img: 'images/p0698.jpg', for: 'women', sizes: "S, M, L" },
    { id: 15, cat: 'perruques', fr: "Perruque blonde ondulée", en: "Blonde body wave wig", price: 120000, img: 'images/p0695.jpg', for: 'women', badge: 'best', featured: true, sizes: "22\", 26\"" },
    { id: 16, cat: 'perruques', fr: "Perruque ombrée cuivre", en: "Copper ombré wig", price: 95000, img: 'images/p0692.jpg', for: 'women', sizes: "18\", 22\"" },
    { id: 17, cat: 'perruques', fr: "Perruque lisse miel", en: "Honey straight wig", price: 110000, img: 'images/p0686.jpg', for: 'women', sizes: "26\", 30\"" },
    { id: 18, cat: 'perruques', fr: "Carré rose", en: "Pink bob wig", price: 55000, old: 65000, img: 'images/p0685.jpg', for: 'women', badge: 'promo', sizes: "10\", 12\"" },
    { id: 19, cat: 'perruques', fr: "Carré lisse noir", en: "Black straight bob", price: 50000, img: 'images/p0688.jpg', for: 'women', sizes: "10\", 12\"" },
    { id: 20, cat: 'perruques', fr: "Perruque afro bouclée", en: "Kinky curly wig", price: 70000, img: 'images/p0687.jpg', for: 'women', sizes: "14\", 16\"" },
    { id: 21, cat: 'coiffures', fr: "Brushing volume", en: "Volume blow-out", price: 15000, img: 'images/p0694.jpg', for: 'women', badge: 'best', featured: true },
    { id: 22, cat: 'coiffures', fr: "Chignon boucles blondes", en: "Blonde pin-curl updo", price: 25000, img: 'images/p0693.jpg', for: 'women' },
    { id: 23, cat: 'coiffures', fr: "Tresses knotless", en: "Knotless braids", price: 30000, img: 'images/p0691.jpg', for: 'women', badge: 'new', featured: true },
    { id: 24, cat: 'coiffures', fr: "Faux locs chignon", en: "Faux locs updo", price: 35000, img: 'images/p0690.jpg', for: 'women' },
    { id: 25, cat: 'coiffures', fr: "Butterfly locs", en: "Butterfly locs", price: 35000, img: 'images/p0689.jpg', for: 'women' },
    { id: 26, cat: 'ongles', fr: "Nail art doré", en: "Gold nail art", price: 15000, img: 'images/p0684.jpg', for: 'women', badge: 'new', featured: true },
    { id: 27, cat: 'sacs', fr: "Sac cabas bordeaux + portefeuille", en: "Burgundy tote + wallet", price: 65000, img: 'images/p0728.jpg', for: 'women', featured: true },
    { id: 28, cat: 'sacs', fr: "Sac blanc anse dorée", en: "White bag, gold handle", price: 45000, img: 'images/p0727.jpg', for: 'women', badge: 'new' },
    { id: 29, cat: 'sacs', fr: "Sac anneau crème", en: "Cream ring bag", price: 40000, img: 'images/p0726.jpg', for: 'women' },
    { id: 30, cat: 'sacs', fr: "Sac demi-lune bordeaux", en: "Burgundy moon bag", price: 48000, img: 'images/p0725.jpg', for: 'women', badge: 'best' },
    { id: 31, cat: 'sacs', fr: "Pochette noire dorée", en: "Black & gold clutch", price: 35000, img: 'images/p0724.jpg', for: 'women' },
    { id: 32, cat: 'chaussures', fr: "Bottines plateforme camel", en: "Camel platform boots", price: 45000, img: 'images/p0723.jpg', for: 'unisex', sizes: "37 – 45" },
    { id: 33, cat: 'chaussures', fr: "Mocassins bicolores", en: "Two-tone loafers", price: 55000, img: 'images/p0722.jpg', for: 'men', badge: 'new', featured: true, sizes: "40 – 45" },
    { id: 34, cat: 'chaussures', fr: "Mocassins crantés noirs", en: "Black lug loafers", price: 50000, img: 'images/p0721.jpg', for: 'unisex', sizes: "37 – 45" },
    { id: 35, cat: 'chaussures', fr: "Mules croisées kaki", en: "Khaki cross slides", price: 30000, img: 'images/p0720.jpg', for: 'men', sizes: "40 – 46" },
    { id: 36, cat: 'chaussures', fr: "Sandales H blanches", en: "White H sandals", price: 35000, img: 'images/p0719.jpg', for: 'unisex', badge: 'best', sizes: "37 – 45" },
    { id: 37, cat: 'chaussures', fr: "Baskets rose et blanc", en: "Pink & white sneakers", price: 35000, img: 'images/p0718.jpg', for: 'women', sizes: "36 – 41" },
    { id: 38, cat: 'chaussures', fr: "Baskets argent", en: "Silver sneakers", price: 35000, img: 'images/p0717.jpg', for: 'unisex', sizes: "37 – 45" },
    { id: 39, cat: 'chaussures', fr: "Baskets suède noires", en: "Black suede sneakers", price: 30000, old: 34000, img: 'images/p0716.jpg', for: 'unisex', badge: 'promo', sizes: "37 – 45" },
    { id: 40, cat: 'chaussures', fr: "Escarpins gris talon or", en: "Grey pumps, gold heel", price: 28000, img: 'images/p0715.jpg', for: 'women', sizes: "36 – 41" },
    { id: 41, cat: 'chaussures', fr: "Escarpins vernis talon logo", en: "Patent pumps, logo heel", price: 65000, img: 'images/p0713.jpg', for: 'women', featured: true, sizes: "36 – 41" },
    { id: 42, cat: 'chaussures', fr: "Slingbacks noir et rouge", en: "Black & red slingbacks", price: 55000, img: 'images/p0712.jpg', for: 'women', sizes: "36 – 41" },
    { id: 43, cat: 'chaussures', fr: "Escarpins bijoux", en: "Jewel strap heels", price: 60000, img: 'images/p0711.jpg', for: 'women', badge: 'new', sizes: "36 – 41" },
    { id: 44, cat: 'chaussures', fr: "Escarpins vernis semelle rouge", en: "Red-sole patent pumps", price: 70000, img: 'images/p0714.jpg', for: 'women', badge: 'best', sizes: "36 – 41" },
    { id: 45, cat: 'packs', fr: "Pack Soirée Glam", en: "Glam Night pack", price: 95000, old: 115000, img: 'images/p0708.jpg', for: 'women', badge: 'promo', featured: true,
      pack: { fr: ["Robe sequins","Escarpins bijoux","Pochette dorée","Nail art offert"],
              en: ["Sequin dress","Jewel heels","Gold clutch","Free nail art"] } },
    { id: 46, cat: 'packs', fr: "Pack Beauté Complète", en: "Full Beauty pack", price: 40000, old: 50000, img: 'images/p0684.jpg', for: 'women', badge: 'promo', featured: true,
      pack: { fr: ["Tresses knotless","Nail art doré","Soin du cuir chevelu"],
              en: ["Knotless braids","Gold nail art","Scalp care"] } },
    { id: 47, cat: 'packs', fr: "Pack Gentleman", en: "Gentleman pack", price: 80000, old: 95000, img: 'images/p0722.jpg', for: 'men', badge: 'promo', featured: true,
      pack: { fr: ["Mocassins bicolores","Mules croisées","Cirage offert"],
              en: ["Two-tone loafers","Cross slides","Free shoe polish"] } },
  ],

  // Galerie : toutes les photos des produits apparaissent déjà.
  // Ajoutez ici des photos en plus (réalisations, salon…)
  gallery: [
    // { img: 'images/ma-photo.jpg', fr: 'Titre', en: 'Title', cat: 'coiffures' },
  ],

  // Avis : ces 3 avis sont des EXEMPLES — remplacez-les par les vrais avis reçus sur WhatsApp
  reviews: [
    { name: "Michelle N.", stars: 5, text: "Ma perruque est magnifique, très naturelle. Merci Laure !" },
    { name: "Arielle T.", stars: 5, text: "Tresses impeccables et tenues longtemps. Je reviens !" },
    { name: "Brice K.", stars: 4, text: "Mocassins de qualité, livrés rapidement à Bonamoussadi." },
  ],

  // Questions : ajoutez ici les réponses aux questions reçues sur WhatsApp
  faq: [
    { q: { fr: "Livrez-vous partout à Douala ?", en: "Do you deliver everywhere in Douala?" },
      a: { fr: "Oui, dans toute la ville. Les frais dépendent du quartier.", en: "Yes, all over the city. The fee depends on the area." } },
    { q: { fr: "Comment payer ?", en: "How do I pay?" },
      a: { fr: "Paiement à la réception, en espèces, Orange Money ou MTN MoMo.", en: "Pay on delivery: cash, Orange Money or MTN MoMo." } },
    { q: { fr: "Faut-il prendre rendez-vous pour une coiffure ?", en: "Do I need an appointment for hair?" },
      a: { fr: "Oui, réservez dans l’onglet RDV pour être servie sans attente.", en: "Yes, book in the Book tab to be served without waiting." } },
  ],
};
