/* =============================================================
   LAURE AURA — site vitrine (HTML / CSS / JavaScript)
   Le contenu vient de data.js. Ce fichier construit les pages,
   les animations 3D et l'envoi des messages WhatsApp.
   ============================================================= */
(function () {
  'use strict';
  var S = window.SITE;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var fine = matchMedia('(pointer: fine)').matches;
  var params = new URLSearchParams(location.search);
  var lang = params.get('lang') === 'en' ? 'en' : 'fr';
  var page = document.body.dataset.page || 'home';
  document.documentElement.lang = lang;

  /* ---------- words ---------- */
  var W = {
    fr: { home: 'Accueil', shop: 'Boutique', gallery: 'Galerie', book: 'RDV', about: 'À propos', search: 'Rechercher…',
      kicker: 'Beauté · Mode · Coiffure', shopNow: 'Voir la boutique', bookNow: 'Prendre RDV', cats: 'Catégories', all: 'Tout',
      featured: 'Coups de cœur', newIn: 'Nouveautés', packs: 'Packs beauté', seeAll: 'Tout voir', more: 'Voir plus', hide: 'Masquer',
      order: 'Commander', new: 'Nouveau', best: 'Best-seller', promo: 'Promo', women: 'Femme', men: 'Homme', everyone: 'Tous',
      sortNew: 'Plus récents', sortLow: 'Prix croissant', sortHigh: 'Prix décroissant', promos: 'Promos', none: 'Aucun article trouvé',
      reset: 'Réinitialiser', items: 'articles', packHas: 'Contenu du pack', size: 'Taille / pointure', reviews: 'Avis clients',
      leaveReview: 'Donner mon avis', yourName: 'Votre nom', yourReview: 'Votre avis', send: 'Envoyer sur WhatsApp',
      faq: 'Questions fréquentes', ask: 'Poser une question', yourQ: 'Votre question', why1: 'Qualité choisie', why2: 'Livraison Douala',
      why3: 'Paiement à la réception', galSub: 'Nos réalisations et nos pièces', orderTitle: 'Votre commande', chooseItem: 'Choisissez un article',
      pick: 'Choisir dans la boutique', change: 'Changer', fullName: 'Nom complet', phone: 'Téléphone (WhatsApp)', city: 'Ville',
      area: 'Quartier / adresse', color: 'Couleur', qty: 'Quantité', receive: 'Mode de réception', delivery: 'Livraison',
      pickup: 'Retrait en boutique', note: 'Note (facultatif)', total: 'Total', orderWa: 'Commander sur WhatsApp',
      bookTitle: 'Prendre rendez-vous', service: 'Prestation', other: 'Autre prestation', date: 'Date', time: 'Heure',
      aboutTitle: 'À propos', contact: 'Contact', address: 'Adresse', hours: 'Horaires', follow: 'Suivez-nous', close: 'Fermer',
      required: 'Remplissez les champs obligatoires', ready: 'Message prêt', readyNote: 'Appuyez sur le bouton pour l’envoyer sur WhatsApp.',
      openWa: 'Ouvrir WhatsApp', opened: 'WhatsApp s’ouvre…',
      mOrder: 'NOUVELLE COMMANDE', mBook: 'RENDEZ-VOUS', mReview: 'NOUVEL AVIS', mFaq: 'QUESTION', mItem: 'Article', mPrice: 'Prix',
      mSize: 'Taille', mName: 'Nom', mTel: 'Tél', mCity: 'Ville', mRecv: 'Réception', mPhoto: 'Photo', mSvc: 'Prestation', mAt: 'à',
      mWant: 'Bonjour, je voudrais ceci :', ex: 'Exemple' },
    en: { home: 'Home', shop: 'Shop', gallery: 'Gallery', book: 'Book', about: 'About', search: 'Search…',
      kicker: 'Beauty · Fashion · Hair', shopNow: 'Visit the shop', bookNow: 'Book now', cats: 'Categories', all: 'All',
      featured: 'Favourites', newIn: 'New in', packs: 'Beauty packs', seeAll: 'See all', more: 'View more', hide: 'Hide',
      order: 'Order', new: 'New', best: 'Best seller', promo: 'Sale', women: 'Women', men: 'Men', everyone: 'All',
      sortNew: 'Newest', sortLow: 'Price: low to high', sortHigh: 'Price: high to low', promos: 'On sale', none: 'No item found',
      reset: 'Reset', items: 'items', packHas: 'Pack contents', size: 'Size', reviews: 'Client reviews',
      leaveReview: 'Leave a review', yourName: 'Your name', yourReview: 'Your review', send: 'Send on WhatsApp',
      faq: 'FAQ', ask: 'Ask a question', yourQ: 'Your question', why1: 'Hand-picked quality', why2: 'Delivery in Douala',
      why3: 'Pay on delivery', galSub: 'Our work and our pieces', orderTitle: 'Your order', chooseItem: 'Choose an item',
      pick: 'Pick from the shop', change: 'Change', fullName: 'Full name', phone: 'Phone (WhatsApp)', city: 'City',
      area: 'Area / address', color: 'Colour', qty: 'Quantity', receive: 'How to receive', delivery: 'Delivery',
      pickup: 'Pick up in store', note: 'Note (optional)', total: 'Total', orderWa: 'Order on WhatsApp',
      bookTitle: 'Book an appointment', service: 'Service', other: 'Other service', date: 'Date', time: 'Time',
      aboutTitle: 'About us', contact: 'Contact', address: 'Address', hours: 'Opening hours', follow: 'Follow us', close: 'Close',
      required: 'Please fill in the required fields', ready: 'Message ready', readyNote: 'Tap the button to send it on WhatsApp.',
      openWa: 'Open WhatsApp', opened: 'Opening WhatsApp…',
      mOrder: 'NEW ORDER', mBook: 'APPOINTMENT', mReview: 'NEW REVIEW', mFaq: 'QUESTION', mItem: 'Item', mPrice: 'Price',
      mSize: 'Size', mName: 'Name', mTel: 'Phone', mCity: 'City', mRecv: 'Receive', mPhoto: 'Photo', mSvc: 'Service', mAt: 'at',
      mWant: 'Hello, I would like this:', ex: 'Example' }
  }[lang];

  /* ---------- helpers ---------- */
  function L(o) { return o == null ? '' : (typeof o === 'string' ? o : (o[lang] || o.fr || '')); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function ic(n, cls) { return '<svg class="ic ' + (cls || '') + '" aria-hidden="true"><use href="#i-' + n + '"/></svg>'; }
  function money(n) { return String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' ' + S.currency; }
  function url(file, extra) {
    var p = new URLSearchParams(extra || {});
    if (lang === 'en') p.set('lang', 'en');
    var q = p.toString();
    return file + (q ? '?' + q : '');
  }
  function cat(id) { for (var i = 0; i < S.categories.length; i++) if (S.categories[i].id === id) return S.categories[i]; return null; }
  function prod(id) { for (var i = 0; i < S.products.length; i++) if (S.products[i].id == id) return S.products[i]; return null; }
  function off(p) { return p.old && p.old > p.price ? Math.round(100 - p.price * 100 / p.old) : 0; }
  function sizes(p) { return p.sizes ? p.sizes.split(',').map(function (s) { return s.trim(); }).filter(Boolean) : []; }
  function absUrl(path) { try { return new URL(path, location.href).href; } catch (e) { return path; } }
  var PAGES = { home: 'accueil.html', shop: 'boutique.html', gallery: 'galerie.html', book: 'rdv.html', about: 'a-propos.html', order: 'commande.html' };

  /* ---------- reusable blocks ---------- */
  function card(p, i) {
    var o = off(p), c = cat(p.cat);
    return '<article class="card reveal" data-item data-id="' + p.id + '" data-cat="' + p.cat + '" data-gender="' + p.for + '" data-price="' + p.price +
      '" data-promo="' + (o ? 1 : 0) + '" data-i="' + i + '" data-search="' + esc((p.fr + ' ' + p.en + ' ' + (c ? c.fr + ' ' + c.en : '')).toLowerCase()) + '">' +
      '<div class="card-media tilt"><img src="' + p.img + '" alt="' + esc(L(p)) + '" loading="lazy">' +
      (p.badge ? '<span class="badge badge-' + p.badge + '">' + W[p.badge] + (o && p.badge === 'promo' ? ' −' + o + '%' : '') + '</span>' : '') +
      (p.pack ? '<span class="pack-tag">' + ic('package') + '</span>' : '') + '</div>' +
      '<div class="card-body"><h3>' + esc(L(p)) + '</h3><div class="price">' + money(p.price) + (o ? ' <s>' + money(p.old) + '</s>' : '') + '</div>' +
      '<a class="card-cta" href="' + url(PAGES.order, { id: p.id }) + '">' + ic('shopping-bag') + '<span>' + W.order + '</span></a></div></article>';
  }
  function moreBar() {
    return '<div class="more-bar"><button class="btn btn-line more-btn" type="button">' + ic('chevron-down') + ' <span>' + W.more + '</span></button>' +
      '<button class="btn btn-line less-btn" type="button" hidden>' + ic('chevron-up') + ' <span>' + W.hide + '</span></button></div>';
  }
  function stars(n) { var s = ''; for (var i = 1; i <= 5; i++) s += '<span class="' + (i <= n ? 'on' : '') + '">' + ic('star') + '</span>'; return '<span class="stars" aria-label="' + n + '/5">' + s + '</span>'; }
  function head(title, kicker, link, linkText) {
    return '<div class="sec-head reveal"><div>' + (kicker ? '<span class="kicker">' + kicker + '</span>' : '') + '<h2>' + esc(title) + '</h2></div>' +
      (link ? '<a class="sec-link" href="' + link + '">' + linkText + ' ' + ic('arrow-right') + '</a>' : '') + '</div>';
  }
  function field(name, label, icon, attrs, wide) {
    return '<label class="field' + (wide ? ' field-wide' : '') + '"><span>' + (icon ? ic(icon) + ' ' : '') + label + '</span><input id="f-' + name + '" name="' + name + '" ' + (attrs || '') + '></label>';
  }
  function sheet(id, title, icon, body) {
    return '<div class="sheet" id="' + id + '" hidden><div class="sheet-backdrop" data-close></div><div class="sheet-panel sheet-form">' +
      '<button class="sheet-x" type="button" data-close aria-label="' + W.close + '">' + ic('x') + '</button><h3>' + ic(icon) + ' ' + title + '</h3>' + body + '</div></div>';
  }

  /* ---------- pages ---------- */
  var V = {};
  V.home = function () {
    var feat = S.products.filter(function (p) { return p.featured && !p.pack; });
    var packs = S.products.filter(function (p) { return p.pack; });
    var ring = (feat.length ? feat : S.products).slice(0, 10);
    var cats = S.categories.map(function (c) {
      var items = S.products.filter(function (p) { return p.cat === c.id; });
      var cover = items.filter(function (p) { return p.featured; })[0] || items[0];
      return items.length ? '<a class="cat-tile reveal" href="' + url(PAGES.shop, { cat: c.id }) + '"><span class="cat-img tilt"><img src="' + cover.img + '" alt="" loading="lazy"></span>' +
        '<span class="cat-name">' + ic(c.icon || 'sparkles') + ' ' + esc(L(c)) + '</span><em>' + items.length + '</em></a>' : '';
    }).join('');
    var used = S.categories.filter(function (c) { return S.products.some(function (p) { return p.cat === c.id; }); });
    var marq = ''; for (var k = 0; k < 2; k++) used.forEach(function (c) { marq += '<span>' + esc(L(c)) + '</span><i>✦</i>'; });
    var avg = S.reviews.length ? (S.reviews.reduce(function (a, r) { return a + r.stars; }, 0) / S.reviews.length) : 0;

    return '<section class="hero"><div class="hero-bg" aria-hidden="true"><span class="blob b1"></span><span class="blob b2"></span></div>' +
      '<div class="hero-stage" aria-hidden="true"><div class="ring" style="--n:' + ring.length + '">' +
      ring.map(function (p, i) { return '<div class="ring-item" style="--i:' + i + '"><img src="' + p.img + '" alt="" draggable="false"></div>'; }).join('') +
      '</div><div class="ring-floor"></div></div>' +
      '<div class="hero-text"><span class="kicker reveal">' + W.kicker + '</span><h1 class="hero-title split">' + esc(S.name) + '</h1>' +
      '<p class="hero-tag reveal">' + esc(L(S.tagline)) + '</p><div class="hero-cta reveal">' +
      '<a href="' + url(PAGES.shop) + '" class="btn btn-dark">' + ic('shopping-bag') + ' ' + W.shopNow + '</a>' +
      '<a href="' + url(PAGES.book) + '" class="btn btn-line">' + ic('calendar-heart') + ' ' + W.bookNow + '</a></div></div></section>' +

      '<section class="sec">' + head(W.cats, '', url(PAGES.shop), W.seeAll) + '<div class="cat-rail" data-drag-scroll>' + cats + '</div></section>' +
      '<div class="marquee" aria-hidden="true"><div class="marquee-track">' + marq + '</div></div>' +

      (feat.length ? '<section class="sec">' + head(W.featured, W.newIn, url(PAGES.shop), W.seeAll) +
        '<div class="grid paged" data-step="3">' + feat.map(card).join('') + '</div>' + moreBar() + '</section>' : '') +

      (packs.length ? '<section class="sec sec-dark">' + head(W.packs, '', url(PAGES.shop, { cat: 'packs' }), W.seeAll) + '<div class="packs paged" data-step="3">' +
        packs.map(function (p) {
          var o = off(p);
          return '<article class="pack reveal" data-item data-id="' + p.id + '"><div class="pack-img tilt"><img src="' + p.img + '" alt="" loading="lazy">' +
            (o ? '<span class="badge badge-promo">−' + o + '%</span>' : '') + '</div><div class="pack-body"><h3>' + esc(L(p)) + '</h3><ul>' +
            L(p.pack).map(function (x) { return '<li>' + ic('check') + ' ' + esc(x) + '</li>'; }).join('') + '</ul>' +
            '<div class="price">' + money(p.price) + (o ? ' <s>' + money(p.old) + '</s>' : '') + '</div>' +
            '<a class="btn btn-gold" href="' + url(PAGES.order, { id: p.id }) + '">' + ic('shopping-bag') + ' ' + W.order + '</a></div></article>';
        }).join('') + '</div>' + moreBar() + '</section>' : '') +

      '<section class="sec why"><div class="why-item reveal">' + ic('gem') + '<span>' + W.why1 + '</span></div>' +
      '<div class="why-item reveal" style="--d:1">' + ic('truck') + '<span>' + W.why2 + '</span></div>' +
      '<div class="why-item reveal" style="--d:2">' + ic('shield-check') + '<span>' + W.why3 + '</span></div></section>' +

      '<section class="sec" id="reviews"><div class="sec-head reveal"><div><span class="kicker">' + (avg ? stars(Math.round(avg)) + ' ' + avg.toFixed(1) + '/5 · ' + S.reviews.length : '') + '</span>' +
      '<h2>' + W.reviews + '</h2></div><button class="btn btn-line btn-sm" type="button" data-open="reviewSheet">' + ic('pencil') + ' ' + W.leaveReview + '</button></div>' +
      '<div class="reviews paged" data-step="3">' + S.reviews.map(function (r) {
        return '<figure class="review reveal" data-item>' + ic('quote', 'q') + '<blockquote>' + esc(r.text) + '</blockquote><figcaption><span class="avatar">' +
          esc(r.name.charAt(0).toUpperCase()) + '</span><b>' + esc(r.name) + '</b>' + stars(r.stars) + '</figcaption></figure>';
      }).join('') + '</div>' + moreBar() + '</section>' +

      '<section class="sec" id="faq"><div class="sec-head reveal"><div><h2>' + W.faq + '</h2></div>' +
      '<button class="btn btn-line btn-sm" type="button" data-open="faqSheet">' + ic('circle-help') + ' ' + W.ask + '</button></div>' +
      '<div class="faq paged" data-step="5">' + S.faq.map(function (f) {
        return '<details class="faq-item reveal" data-item><summary><span>' + esc(L(f.q)) + '</span>' + ic('chevron-down') + '</summary><div class="faq-a"><p>' + esc(L(f.a)) + '</p></div></details>';
      }).join('') + '</div>' + moreBar() + '</section>' +

      '<section class="sec cta-band reveal"><img src="' + S.logo + '" alt="" class="cta-logo"><h2>' + W.bookTitle + '</h2><div class="hero-cta">' +
      '<a href="' + url(PAGES.book) + '" class="btn btn-dark">' + ic('calendar-heart') + ' ' + W.bookNow + '</a>' +
      '<a href="https://wa.me/' + S.whatsapp + '" target="_blank" rel="noopener" class="btn btn-wa">' + ic('whatsapp') + ' WhatsApp</a></div></section>' +

      sheet('reviewSheet', W.leaveReview, 'message-square-quote', '<form class="wa-form" data-kind="review" novalidate><div class="star-input" role="radiogroup">' +
        [5, 4, 3, 2, 1].map(function (i) { return '<input type="radio" name="stars" id="r' + i + '" value="' + i + '"' + (i === 5 ? ' checked' : '') + '><label for="r' + i + '" aria-label="' + i + '">' + ic('star') + '</label>'; }).join('') +
        '</div>' + field('rname', W.yourName, '', 'required maxlength="60"') +
        '<label class="field"><span>' + W.yourReview + '</span><textarea id="f-rtext" name="rtext" required maxlength="600" rows="3"></textarea></label>' +
        '<button class="btn btn-wa btn-block" type="submit">' + ic('whatsapp') + ' ' + W.send + '</button></form>') +
      sheet('faqSheet', W.ask, 'circle-help', '<form class="wa-form" data-kind="faq" novalidate>' + field('qname', W.yourName, '', 'maxlength="60"') +
        '<label class="field"><span>' + W.yourQ + '</span><textarea id="f-qtext" name="qtext" required maxlength="500" rows="3"></textarea></label>' +
        '<button class="btn btn-wa btn-block" type="submit">' + ic('whatsapp') + ' ' + W.send + '</button></form>');
  };

  V.shop = function () {
    return '<section class="page-head"><h1 class="split">' + W.shop + '</h1></section>' +
      '<div class="filters" id="filters"><label class="search-box">' + ic('search') + '<input type="search" id="q" placeholder="' + W.search + '" autocomplete="off">' +
      '<button type="button" class="clear-q" hidden aria-label="' + W.reset + '">' + ic('x') + '</button></label><div class="filter-row">' +
      '<div class="dd" id="catDD"><button type="button" class="dd-btn"><span class="dd-val">' + ic('layers') + ' ' + W.all + '</span>' + ic('chevron-down', 'dd-caret') + '</button>' +
      '<div class="dd-menu" role="listbox"><button type="button" data-value="" class="sel">' + ic('layers') + ' ' + W.all + '</button>' +
      S.categories.map(function (c) { return '<button type="button" data-value="' + c.id + '">' + ic(c.icon || 'sparkles') + ' ' + esc(L(c)) + '</button>'; }).join('') + '</div></div>' +
      '<div class="dd" id="sortDD"><button type="button" class="dd-btn"><span class="dd-val">' + ic('sliders-horizontal') + ' ' + W.sortNew + '</span>' + ic('chevron-down', 'dd-caret') + '</button>' +
      '<div class="dd-menu" role="listbox"><button type="button" data-value="new" class="sel">' + ic('sparkles') + ' ' + W.sortNew + '</button>' +
      '<button type="button" data-value="low">' + ic('arrow-right') + ' ' + W.sortLow + '</button><button type="button" data-value="high">' + ic('arrow-left') + ' ' + W.sortHigh + '</button></div></div></div>' +
      '<div class="seg" id="genderSeg"><button type="button" data-g="" class="on">' + W.everyone + '</button><button type="button" data-g="women">' + W.women + '</button>' +
      '<button type="button" data-g="men">' + W.men + '</button><button type="button" data-g="promo" class="seg-promo">' + ic('badge-percent') + ' ' + W.promos + '</button></div></div>' +
      '<section class="sec sec-tight"><p class="result-count"><b id="count">' + S.products.length + '</b> ' + W.items + '</p>' +
      '<div class="grid paged" data-step="6" id="shopGrid">' + S.products.slice().reverse().map(card).join('') + '</div>' +
      '<div class="empty-state" id="noResults" hidden>' + ic('search') + '<p>' + W.none + '</p><button class="btn btn-line btn-sm" type="button" id="resetFilters">' + ic('refresh-cw') + ' ' + W.reset + '</button></div>' +
      moreBar() + '</section>';
  };

  function galleryItems() {
    var items = S.products.map(function (p) { return { img: p.img, t: L(p), cat: p.cat, id: p.id }; });
    return items.concat((S.gallery || []).map(function (g) { return { img: g.img, t: L(g), cat: g.cat || '' }; }));
  }
  V.gallery = function () {
    var items = galleryItems(), used = [];
    items.forEach(function (g) { if (g.cat && used.indexOf(g.cat) < 0) used.push(g.cat); });
    return '<section class="page-head"><h1 class="split">' + W.gallery + '</h1><p class="reveal">' + W.galSub + '</p></section>' +
      '<div class="pills" id="galPills" data-drag-scroll><button type="button" class="pill on" data-f="">' + W.all + '</button>' +
      S.categories.filter(function (c) { return used.indexOf(c.id) > -1; }).map(function (c) { return '<button type="button" class="pill" data-f="' + c.id + '">' + esc(L(c)) + '</button>'; }).join('') + '</div>' +
      '<section class="sec sec-tight"><div class="masonry paged" data-step="12" id="masonry">' +
      items.map(function (g, i) {
        return '<figure class="pin" data-item data-cat="' + g.cat + '" data-idx="' + i + '"' + (g.id ? ' data-id="' + g.id + '"' : '') + '><img src="' + g.img + '" alt="' + esc(g.t) + '" loading="lazy">' +
          '<figcaption><span>' + esc(g.t) + '</span><span class="pin-zoom">' + ic('eye') + '</span></figcaption></figure>';
      }).join('') + '</div>' + moreBar() + '</section>' +
      '<div class="lightbox" id="lightbox" hidden><button class="lb-x" type="button" aria-label="' + W.close + '">' + ic('x') + '</button>' +
      '<button class="lb-nav prev" type="button" aria-label="prev">' + ic('chevron-left') + '</button><figure><img alt=""><figcaption></figcaption></figure>' +
      '<button class="lb-nav next" type="button" aria-label="next">' + ic('chevron-right') + '</button>' +
      '<a class="btn btn-gold lb-order" href="#">' + ic('shopping-bag') + ' ' + W.order + '</a></div>';
  };

  V.order = function () {
    return '<section class="page-head"><h1 class="split">' + W.orderTitle + '</h1></section><section class="sec sec-tight order-wrap">' +
      '<form class="order-form wa-form" id="orderForm" data-kind="order" novalidate><input type="hidden" name="pid" id="pid">' +
      '<div class="picked is-empty" id="picked"><div class="picked-img tilt"><img id="pImg" alt=""></div><div class="picked-info"><span class="kicker" id="pCat"></span>' +
      '<h3 id="pName">' + W.chooseItem + '</h3><div class="price" id="pPrice"></div>' +
      '<button type="button" class="btn btn-line btn-sm" data-open="pickerSheet">' + ic('shopping-bag') + ' <span id="pickLabel">' + W.pick + '</span></button></div></div>' +
      '<div class="form-grid">' + field('name', W.fullName + ' *', 'user', 'required maxlength="80" autocomplete="name"') +
      field('phone', W.phone + ' *', 'phone', 'required type="tel" maxlength="20" inputmode="tel" placeholder="6XX XX XX XX" autocomplete="tel"') +
      field('city', W.city + ' *', 'map-pin', 'required value="Douala" maxlength="60"') + field('area', W.area, 'house', 'maxlength="120" placeholder="Bonamoussadi, Akwa…"') +
      '<div class="field" id="sizeField" hidden><span>' + ic('ruler') + ' ' + W.size + '</span><input id="f-size" name="size" maxlength="30"></div>' +
      field('color', W.color, 'palette', 'maxlength="40"') +
      '<div class="field"><span>' + ic('package') + ' ' + W.qty + '</span><div class="stepper"><button type="button" data-step="-1" aria-label="-">' + ic('minus') + '</button>' +
      '<input id="qty" name="qty" type="number" min="1" max="50" value="1" inputmode="numeric"><button type="button" data-step="1" aria-label="+">' + ic('plus') + '</button></div></div>' +
      '<div class="field"><span>' + ic('truck') + ' ' + W.receive + '</span><div class="seg seg-full"><label><input type="radio" name="recv" value="delivery" checked><span>' + ic('truck') + ' ' + W.delivery + '</span></label>' +
      '<label><input type="radio" name="recv" value="pickup"><span>' + ic('store') + ' ' + W.pickup + '</span></label></div></div>' +
      '<label class="field field-wide"><span>' + ic('pencil') + ' ' + W.note + '</span><textarea id="f-note" name="note" rows="2" maxlength="400"></textarea></label></div>' +
      '<div class="order-total"><span>' + W.total + '</span><b id="total">—</b></div>' +
      '<button class="btn btn-wa btn-block btn-lg" type="submit">' + ic('whatsapp') + ' ' + W.orderWa + '</button></form></section>' +
      '<div class="sheet" id="pickerSheet" hidden><div class="sheet-backdrop" data-close></div><div class="sheet-panel sheet-tall">' +
      '<button class="sheet-x" type="button" data-close aria-label="' + W.close + '">' + ic('x') + '</button><h3>' + ic('shopping-bag') + ' ' + W.chooseItem + '</h3>' +
      '<label class="search-box">' + ic('search') + '<input type="search" id="pickQ" placeholder="' + W.search + '" autocomplete="off"></label><div class="pick-grid">' +
      S.products.map(function (p) {
        var c = cat(p.cat);
        return '<button type="button" class="pick" data-id="' + p.id + '" data-search="' + esc((p.fr + ' ' + p.en + ' ' + (c ? c.fr + ' ' + c.en : '')).toLowerCase()) + '">' +
          '<img src="' + p.img + '" alt="" loading="lazy"><span>' + esc(L(p)) + '</span><b>' + money(p.price) + '</b></button>';
      }).join('') + '</div></div></div>';
  };

  V.book = function () {
    var groups = S.categories.filter(function (c) { return c.booking; }).map(function (c) {
      var items = S.products.filter(function (p) { return p.cat === c.id; });
      return items.length ? '<div class="dd-group">' + ic(c.icon) + ' ' + esc(L(c)) + '</div>' + items.map(function (p) {
        return '<button type="button" data-value="' + esc(L(p) + ' · ' + money(p.price)) + '" data-img="' + p.img + '" data-id="' + p.id + '"><img src="' + p.img + '" alt="" loading="lazy"><span>' + esc(L(p)) + '</span><b>' + money(p.price) + '</b></button>';
      }).join('') : '';
    }).join('');
    var d = new Date(); d.setDate(d.getDate() + 1);
    var iso = function (x) { return x.getFullYear() + '-' + ('0' + (x.getMonth() + 1)).slice(-2) + '-' + ('0' + x.getDate()).slice(-2); };
    var slots = ['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00'];
    return '<section class="page-head"><h1 class="split">' + W.bookTitle + '</h1></section><section class="sec sec-tight order-wrap">' +
      '<form class="order-form wa-form" id="bookForm" data-kind="book" novalidate><div class="field"><span>' + ic('scissors') + ' ' + W.service + ' *</span>' +
      '<div class="dd dd-block" id="serviceDD"><input type="hidden" name="service" id="serviceVal" required>' +
      '<button type="button" class="dd-btn"><span class="dd-val">' + ic('sparkles') + ' ' + W.service + '…</span>' + ic('chevron-down', 'dd-caret') + '</button>' +
      '<div class="dd-menu dd-scroll" role="listbox">' + groups + '<button type="button" data-value="' + W.other + '">' + ic('plus') + ' <span>' + W.other + '</span></button></div></div></div>' +
      '<div class="form-grid">' + field('day', W.date + ' *', 'calendar', 'type="date" required min="' + iso(new Date()) + '" value="' + iso(d) + '"') +
      '<div class="field"><span>' + ic('clock') + ' ' + W.time + ' *</span><div class="slots">' +
      slots.map(function (s, i) { return '<label><input type="radio" name="hour" value="' + s + '"' + (i === 2 ? ' checked' : '') + '><span>' + s + '</span></label>'; }).join('') + '</div></div>' +
      field('name', W.fullName + ' *', 'user', 'required maxlength="80" autocomplete="name"') +
      field('phone', W.phone + ' *', 'phone', 'required type="tel" maxlength="20" inputmode="tel" placeholder="6XX XX XX XX"') +
      '<label class="field field-wide"><span>' + ic('pencil') + ' ' + W.note + '</span><textarea id="f-note" name="note" rows="2" maxlength="400"></textarea></label></div>' +
      '<button class="btn btn-wa btn-block btn-lg" type="submit">' + ic('whatsapp') + ' ' + W.bookNow + '</button></form></section>';
  };

  V.about = function () {
    var imgs = S.products.filter(function (p) { return p.featured; }).slice(0, 3);
    var so = '';
    ['instagram', 'facebook', 'tiktok'].forEach(function (k) { if (S.socials[k]) so += '<a href="' + esc(S.socials[k]) + '" target="_blank" rel="noopener" aria-label="' + k + '">' + ic(k) + '</a>'; });
    return '<section class="about-hero"><div class="about-logo tilt-deep"><img src="' + S.logo + '" alt=""></div><h1 class="split">' + esc(S.name) + '</h1>' +
      '<p class="hero-tag reveal">' + esc(L(S.tagline)) + '</p></section><section class="sec sec-tight about-body"><div class="about-text reveal">' +
      L(S.about).split('\n').filter(Boolean).map(function (x) { return '<p>' + esc(x) + '</p>'; }).join('') + '</div><div class="about-stack" aria-hidden="true">' +
      imgs.map(function (p) { return '<img src="' + p.img + '" alt="" class="reveal">'; }).join('') + '</div></section>' +
      '<section class="sec info-cards"><a class="info reveal" href="https://wa.me/' + S.whatsapp + '" target="_blank" rel="noopener"><span class="info-ic wa">' + ic('whatsapp') + '</span>' +
      '<span><small>' + W.contact + '</small><b>' + esc(S.phone) + '</b></span>' + ic('arrow-right', 'go') + '</a>' +
      '<a class="info reveal" style="--d:1" href="https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(S.name + ' ' + S.address) + '" target="_blank" rel="noopener">' +
      '<span class="info-ic">' + ic('map-pin') + '</span><span><small>' + W.address + '</small><b>' + esc(S.address) + '</b></span>' + ic('arrow-right', 'go') + '</a>' +
      '<div class="info reveal" style="--d:2"><span class="info-ic">' + ic('clock') + '</span><span><small>' + W.hours + '</small><b>' + esc(L(S.hours)).replace(/\n/g, '<br>') + '</b></span></div>' +
      (S.email ? '<div class="info reveal" style="--d:3"><span class="info-ic">' + ic('mail') + '</span><span><small>Email</small><b>' + esc(S.email) + '</b></span></div>' : '') + '</section>' +
      '<section class="sec cta-band reveal"><h2>' + W.follow + '</h2><div class="socials big"><a href="https://wa.me/' + S.whatsapp + '" target="_blank" rel="noopener" aria-label="WhatsApp">' + ic('whatsapp') + '</a>' + so + '</div></section>';
  };

  /* ---------- page shell ---------- */
  function shell() {
    var nav = [['home', 'house'], ['shop', 'shopping-bag'], ['gallery', 'images'], ['book', 'calendar-heart'], ['about', 'info']];
    var active = page === 'order' ? 'shop' : page;
    var letters = Array.from(S.name.toUpperCase()).map(function (c, i) { return '<span style="--i:' + i + '">' + (c === ' ' ? '&nbsp;' : esc(c)) + '</span>'; }).join('');
    var so = ''; ['instagram', 'facebook', 'tiktok'].forEach(function (k) { if (S.socials[k]) so += '<a href="' + esc(S.socials[k]) + '" target="_blank" rel="noopener" aria-label="' + k + '">' + ic(k) + '</a>'; });
    var other = lang === 'fr' ? 'en' : 'fr';
    var p2 = new URLSearchParams(location.search); if (other === 'en') p2.set('lang', 'en'); else p2.delete('lang');
    var langHref = location.pathname.split('/').pop() + (p2.toString() ? '?' + p2 : '');
    if (!langHref || langHref.charAt(0) === '?' || langHref === 'index.html' || langHref.indexOf('index.html?') === 0) langHref = 'accueil.html' + (langHref.split('?')[1] ? '?' + langHref.split('?')[1] : '');

    return '<div class="intro" id="intro" aria-hidden="true"><div class="intro-half top"></div><div class="intro-half bottom"></div><div class="intro-core">' +
      '<div class="intro-logo"><svg class="intro-ring" viewBox="0 0 200 200"><circle cx="100" cy="100" r="96"/></svg><img src="' + S.logo + '" alt=""></div>' +
      '<div class="intro-name">' + letters + '</div></div></div>' +
      '<header class="topbar"><a href="' + url(PAGES.home) + '" class="brand"><img src="' + S.logo + '" alt="' + esc(S.name) + '"><span>' + esc(S.name) + '</span></a>' +
      '<div class="top-actions"><a class="lang-switch" href="' + langHref + '" aria-label="Language"><b class="' + (lang === 'fr' ? 'on' : '') + '">FR</b><b class="' + (lang === 'en' ? 'on' : '') + '">EN</b></a>' +
      '<a class="icon-btn" href="' + url(PAGES.shop, { focus: 1 }) + '" aria-label="' + W.search + '">' + ic('search') + '</a></div></header>' +
      '<main class="page" id="page">' + V[page]() +
      '<footer class="site-footer"><img class="foot-logo" src="' + S.logo + '" alt=""><p class="foot-tag">' + esc(L(S.tagline)) + '</p>' +
      '<div class="socials"><a href="https://wa.me/' + S.whatsapp + '" target="_blank" rel="noopener" aria-label="WhatsApp">' + ic('whatsapp') + '</a>' + so + '</div>' +
      '<p class="foot-small">© ' + new Date().getFullYear() + ' ' + esc(S.name) + ' · ' + esc(S.address) + '</p></footer></main>' +
      '<nav class="dock" aria-label="Navigation">' + nav.map(function (n) {
        return '<a href="' + url(PAGES[n[0]]) + '" class="dock-item ' + (active === n[0] ? 'active" aria-current="page' : '') + '"><span class="dock-ic">' + ic(n[1]) + '</span><span class="dock-label">' + W[n[0]] + '</span></a>';
      }).join('') + '</nav>' +
      '<a class="wa-float" href="https://wa.me/' + S.whatsapp + '" target="_blank" rel="noopener" aria-label="WhatsApp">' + ic('whatsapp') + '</a>' +
      '<div class="sheet" id="productSheet" hidden><div class="sheet-backdrop" data-close></div><div class="sheet-panel"><button class="sheet-x" type="button" data-close aria-label="' + W.close + '">' + ic('x') + '</button>' +
      '<div class="ps-media"><img alt=""></div><div class="ps-body"><span class="ps-cat"></span><h3 class="ps-name"></h3><div class="ps-price"></div>' +
      '<div class="ps-pack" hidden><h4>' + ic('package') + ' ' + W.packHas + '</h4><ul></ul></div><div class="ps-sizes" hidden><h4>' + ic('ruler') + ' ' + W.size + '</h4><div class="chips"></div></div>' +
      '<div class="ps-actions"><a class="btn btn-dark ps-order" href="#">' + ic('shopping-bag') + ' ' + W.order + '</a></div></div></div></div>' +
      '<div class="sheet" id="waSheet" hidden><div class="sheet-backdrop" data-close></div><div class="sheet-panel sheet-form">' +
      '<button class="sheet-x" type="button" data-close aria-label="' + W.close + '">' + ic('x') + '</button><h3>' + ic('whatsapp') + ' ' + W.ready + '</h3>' +
      '<pre class="wa-bubble"></pre><p class="wa-note">' + W.readyNote + '</p><a class="btn btn-wa btn-block btn-lg wa-go" target="_blank" rel="noopener" href="#">' + ic('whatsapp') + ' ' + W.openWa + '</a></div></div>' +
      '<div class="toast" id="toast" role="status" hidden></div>';
  }

  document.body.className = 'page-' + page;
  document.body.insertAdjacentHTML('beforeend', shell());
  document.title = (page === 'home' ? S.name + ' — ' + L(S.tagline) : (W[page === 'order' ? 'orderTitle' : page === 'book' ? 'bookTitle' : page] + ' · ' + S.name));
  try { if (sessionStorage.getItem('la_intro')) document.documentElement.classList.add('no-intro'); } catch (e) {}

  /* ================= motion ================= */
  var intro = $('#intro');
  var introDone = document.documentElement.classList.contains('no-intro');
  if (introDone && intro) intro.remove();
  function endIntro() {
    if (introDone) return;
    introDone = true; intro.classList.add('done');
    try { sessionStorage.setItem('la_intro', '1'); } catch (e) {}
    setTimeout(function () { intro.remove(); }, 1100);
    watch();
  }
  if (!introDone) {
    var t0 = Date.now(), minT = reduce ? 300 : 2300;
    var go = function () { setTimeout(endIntro, Math.max(0, minT - (Date.now() - t0))); };
    if (document.readyState === 'complete') go(); else addEventListener('load', go);
    setTimeout(endIntro, 3200);
    intro.addEventListener('click', endIntro);
  }

  // animated titles, letter by letter (words never break)
  $$('.split').forEach(function (el) {
    var txt = el.textContent.trim(), i = 0;
    el.setAttribute('aria-label', txt); el.innerHTML = '';
    txt.split(/\s+/).forEach(function (word, w) {
      if (w) el.appendChild(document.createTextNode(' '));
      var wrap = document.createElement('span'); wrap.className = 'word'; wrap.setAttribute('aria-hidden', 'true');
      Array.from(word).forEach(function (c) { var s = document.createElement('span'); s.className = 'ch'; s.style.setProperty('--c', i++); s.textContent = c; wrap.appendChild(s); });
      el.appendChild(wrap);
    });
  });

  var io = 'IntersectionObserver' in window ? new IntersectionObserver(function (ents) {
    ents.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } });
  }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 }) : null;
  function watch(root) { $$('.reveal:not(.in), .split:not(.in)', root).forEach(function (el) { io ? io.observe(el) : el.classList.add('in'); }); }
  if (introDone) watch();
  document.documentElement.classList.add('js');

  // page transitions
  document.addEventListener('click', function (e) {
    var a = e.target.closest('a');
    if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || a.target === '_blank') return;
    var href = a.getAttribute('href');
    if (!href || href.charAt(0) === '#' || /^(https?:|mailto:|tel:)/.test(href)) return;
    e.preventDefault();
    document.documentElement.classList.add('leaving');
    setTimeout(function () { location.href = href; }, reduce ? 0 : 260);
  });
  addEventListener('pageshow', function (ev) { if (ev.persisted) document.documentElement.classList.remove('leaving'); });
  addEventListener('scroll', function () {
    document.documentElement.classList.toggle('scrolled', scrollY > 8);
    var f = $('.filters'); if (f) f.classList.toggle('stuck', scrollY > 120);
  }, { passive: true });

  // 3D tilt under the mouse
  function bindTilt(root) {
    if (!fine || reduce) return;
    $$('.tilt:not([data-t]), .tilt-deep:not([data-t])', root).forEach(function (el) {
      el.dataset.t = 1;
      var deep = el.classList.contains('tilt-deep') ? 16 : 9;
      el.addEventListener('pointermove', function (e) {
        var r = el.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
        el.style.transform = 'perspective(800px) rotateY(' + ((x - .5) * deep) + 'deg) rotateX(' + ((.5 - y) * deep) + 'deg) scale(1.02)';
        el.style.setProperty('--gx', x * 100 + '%'); el.style.setProperty('--gy', y * 100 + '%'); el.classList.add('tilting');
      });
      el.addEventListener('pointerleave', function () { el.style.transform = ''; el.classList.remove('tilting'); });
    });
  }
  bindTilt();

  // hero 3D carousel: spins, can be dragged
  var ring = $('.ring');
  if (ring) {
    var stage = ring.closest('.hero-stage'), n = ring.children.length || 1;
    var setR = function () { var w = ring.offsetWidth; ring.style.setProperty('--rz', Math.round((w / 2) / Math.tan(Math.PI / n) * 1.12) + 'px'); };
    setR(); addEventListener('resize', setR);
    var angle = 0, base = reduce ? 0 : -0.12, vel = base, dragging = false, lastX = 0, tiltX = -6;
    stage.addEventListener('pointerdown', function (e) { dragging = true; lastX = e.clientX; stage.setPointerCapture(e.pointerId); });
    stage.addEventListener('pointermove', function (e) {
      if (dragging) { var dx = e.clientX - lastX; lastX = e.clientX; angle += dx * 0.35; vel = dx * 0.35; }
      else if (fine) { var r = stage.getBoundingClientRect(); tiltX = -6 + ((e.clientY - r.top) / r.height - .5) * -10; }
    });
    var up = function () { dragging = false; };
    stage.addEventListener('pointerup', up); stage.addEventListener('pointercancel', up);
    (function loop() {
      if (!dragging) { vel += (base - vel) * 0.03; angle += vel; }
      ring.style.transform = 'rotateX(' + tiltX + 'deg) rotateY(' + angle + 'deg)';
      requestAnimationFrame(loop);
    })();
  }

  // drag to scroll rails with the mouse
  $$('[data-drag-scroll]').forEach(function (el) {
    var down = false, sx = 0, sl = 0, moved = false;
    el.addEventListener('pointerdown', function (e) { if (e.pointerType !== 'mouse') return; down = true; moved = false; sx = e.clientX; sl = el.scrollLeft; });
    addEventListener('pointerup', function () { down = false; });
    el.addEventListener('pointermove', function (e) { if (!down) return; var d = e.clientX - sx; if (Math.abs(d) > 5) moved = true; el.scrollLeft = sl - d; });
    el.addEventListener('click', function (e) { if (moved) { e.preventDefault(); e.stopPropagation(); } }, true);
  });

  /* ---------- VIEW MORE / HIDE ---------- */
  var pagers = [];
  function cols(list) { return list.classList.contains('grid') ? (getComputedStyle(list).gridTemplateColumns.split(' ').length || 1) : 1; }
  $$('.paged').forEach(function (list) {
    var bar = list.parentElement.querySelector('.more-bar'); if (!bar) return;
    var more = $('.more-btn', bar), less = $('.less-btn', bar), baseStep = +list.dataset.step || 3, shown = 0;
    var step = function () { var c = cols(list); return c > 1 ? Math.ceil(baseStep / c) * c : baseStep; };
    var items = function () { return $$(':scope > [data-item]', list).filter(function (i) { return !i.classList.contains('is-filtered'); }); };
    function apply(from) {
      var its = items();
      its.forEach(function (it, i) {
        var hide = i >= shown; it.classList.toggle('is-paged', hide);
        if (!hide && from > -1 && i >= from) {
          it.classList.remove('just-shown'); void it.offsetWidth; it.style.setProperty('--k', i - from);
          it.classList.add('just-shown', 'in'); $$('.reveal', it).forEach(function (r) { r.classList.add('in'); });
        }
      });
      $$(':scope > [data-item].is-filtered', list).forEach(function (it) { it.classList.remove('is-paged'); });
      more.hidden = shown >= its.length; less.hidden = shown <= step(); bar.hidden = more.hidden && less.hidden;
    }
    function reset() { shown = step(); apply(-1); }
    more.addEventListener('click', function () { var f = shown; shown += step(); apply(f); bindTilt(list); });
    less.addEventListener('click', function () {
      reset(); var top = list.getBoundingClientRect().top + scrollY - 140;
      if (scrollY > top) scrollTo({ top: top, behavior: reduce ? 'auto' : 'smooth' });
    });
    reset();
    var lastC = cols(list);
    addEventListener('resize', function () { var c = cols(list); if (c !== lastC) { lastC = c; reset(); } });
    list._pager = { reset: reset }; pagers.push(list);
  });

  /* ---------- dropdowns ---------- */
  function initDD(dd, onPick) {
    var val = $('.dd-val', dd);
    $('.dd-btn', dd).addEventListener('click', function (e) { e.stopPropagation(); var open = dd.classList.contains('open'); closeDDs(); if (!open) dd.classList.add('open'); });
    $$('.dd-menu button', dd).forEach(function (b) {
      b.addEventListener('click', function () {
        $$('.dd-menu button', dd).forEach(function (x) { x.classList.remove('sel'); }); b.classList.add('sel');
        val.innerHTML = b.dataset.img ? '<img src="' + b.dataset.img + '" alt="">' + esc(($('span', b) || b).textContent) : b.innerHTML.replace(/<b>.*<\/b>/, '');
        dd.classList.remove('open');
        var f = dd.closest('.field'); if (f) f.classList.remove('invalid');
        if (onPick) onPick(b.dataset.value, b);
      });
    });
  }
  function closeDDs() { $$('.dd.open').forEach(function (d) { d.classList.remove('open'); }); }
  document.addEventListener('click', closeDDs);

  /* ---------- sheets + toast ---------- */
  function openSheet(id) {
    var s = document.getElementById(id); if (!s) return;
    s.hidden = false; document.body.style.overflow = 'hidden';
    requestAnimationFrame(function () { requestAnimationFrame(function () { s.classList.add('open'); }); });
  }
  function closeSheets() {
    $$('.sheet.open').forEach(function (s) { s.classList.remove('open'); setTimeout(function () { s.hidden = true; }, 450); });
    document.body.style.overflow = '';
  }
  document.addEventListener('click', function (e) {
    var o = e.target.closest('[data-open]'); if (o) { e.preventDefault(); openSheet(o.dataset.open); }
    if (e.target.closest('.sheet [data-close]')) closeSheets();
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { closeDDs(); closeSheets(); } });
  var tt;
  function toast(msg, err) {
    var t = $('#toast'); t.textContent = msg; t.classList.toggle('err', !!err); t.hidden = false;
    requestAnimationFrame(function () { t.classList.add('show'); });
    clearTimeout(tt); tt = setTimeout(function () { t.classList.remove('show'); setTimeout(function () { t.hidden = true; }, 400); }, 3000);
  }

  /* ---------- quick view of a product ---------- */
  document.addEventListener('click', function (e) {
    var m = e.target.closest('.card-media, .pack-img'); if (!m) return;
    var p = prod(m.closest('[data-id]').dataset.id); if (!p) return;
    var s = $('#productSheet'), o = off(p), c = cat(p.cat);
    $('.ps-media img', s).src = p.img; $('.ps-cat', s).textContent = c ? L(c) : '';
    $('.ps-name', s).textContent = L(p);
    $('.ps-price', s).innerHTML = money(p.price) + (o ? ' <s>' + money(p.old) + '</s>' : '');
    var pk = $('.ps-pack', s), list = p.pack ? L(p.pack) : [];
    pk.hidden = !list.length; $('ul', pk).innerHTML = list.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('');
    var sz = $('.ps-sizes', s), zs = sizes(p);
    sz.hidden = !zs.length; $('.chips', sz).innerHTML = zs.map(function (x) { return '<span>' + esc(x) + '</span>'; }).join('');
    $('.ps-order', s).href = url(PAGES.order, { id: p.id });
    openSheet('productSheet');
  });

  /* ---------- send to WhatsApp ---------- */
  function sendWa(text) {
    var link = 'https://wa.me/' + S.whatsapp + '?text=' + encodeURIComponent(text);
    var w = null;
    try { w = window.open(link, '_blank'); } catch (e) {}
    if (w) { toast(W.opened); return; }
    // pop-up blocked: show the message with a button to open WhatsApp
    var s = $('#waSheet');
    $('.wa-bubble', s).textContent = text; $('.wa-go', s).href = link;
    closeSheets(); setTimeout(function () { openSheet('waSheet'); }, 460);
  }
  function v(form, name) { var el = form.elements[name]; return el ? String(el.value).trim() : ''; }
  var builders = {
    review: function (f) {
      return '*' + W.mReview + ' — ' + S.name + '*\n\n' + '★★★★★'.slice(0, +v(f, 'stars') || 5) + '\n' + v(f, 'rtext') + '\n\n— ' + v(f, 'rname');
    },
    faq: function (f) {
      return '*' + W.mFaq + ' — ' + S.name + '*\n\n' + v(f, 'qtext') + (v(f, 'qname') ? '\n\n— ' + v(f, 'qname') : '');
    },
    order: function (f) {
      var p = prod(v(f, 'pid')), q = Math.max(1, +v(f, 'qty') || 1), c = cat(p.cat);
      var t = ['*' + W.mOrder + ' — ' + S.name + '*', '', W.mItem + ' : ' + L(p) + (c ? ' (' + L(c) + ')' : ''), W.mPrice + ' : ' + money(p.price) + ' × ' + q,
        '*' + W.total + ' : ' + money(p.price * q) + '*'];
      if (v(f, 'size')) t.push(W.mSize + ' : ' + v(f, 'size'));
      if (v(f, 'color')) t.push(W.color + ' : ' + v(f, 'color'));
      t.push('', W.mName + ' : ' + v(f, 'name'), W.mTel + ' : ' + v(f, 'phone'), W.mCity + ' : ' + v(f, 'city') + (v(f, 'area') ? ' — ' + v(f, 'area') : ''),
        W.mRecv + ' : ' + (f.elements.recv.value === 'pickup' ? W.pickup : W.delivery));
      if (v(f, 'note')) t.push('Note : ' + v(f, 'note'));
      t.push('', W.mPhoto + ' : ' + absUrl(p.img));
      return t.join('\n');
    },
    book: function (f) {
      var d = v(f, 'day').split('-').reverse().join('/');
      var t = ['*' + W.mBook + ' — ' + S.name + '*', '', W.mSvc + ' : ' + v(f, 'service'), W.date + ' : ' + d + ' ' + W.mAt + ' ' + f.elements.hour.value, '',
        W.mName + ' : ' + v(f, 'name'), W.mTel + ' : ' + v(f, 'phone')];
      if (v(f, 'note')) t.push('Note : ' + v(f, 'note'));
      return t.join('\n');
    }
  };
  $$('.wa-form').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var bad = null;
      $$('[required]', form).forEach(function (inp) {
        var f = inp.closest('.field') || inp.parentElement, empty = !String(inp.value).trim();
        f.classList.toggle('invalid', empty); if (empty && !bad) bad = f;
      });
      if (form.dataset.kind === 'order' && !v(form, 'pid')) { $('#picked').classList.add('invalid'); bad = bad || $('#picked'); setTimeout(function () { openSheet('pickerSheet'); }, 400); }
      if (bad) { bad.scrollIntoView({ behavior: 'smooth', block: 'center' }); toast(W.required, true); return; }
      sendWa(builders[form.dataset.kind](form));
      if (form.closest('#reviewSheet, #faqSheet')) { form.reset(); setTimeout(closeSheets, 300); }
    });
    form.addEventListener('input', function (e) { var f = e.target.closest('.field'); if (f) f.classList.remove('invalid'); });
  });

  /* ================= page behaviours ================= */
  if (page === 'shop') {
    var grid = $('#shopGrid'), qi = $('#q'), count = $('#count'), none = $('#noResults'), clear = $('.clear-q');
    var state = { cat: params.get('cat') || '', g: '', sort: 'new', q: '' };
    var cards = $$('[data-item]', grid);
    var norm = function (s) { return s.normalize('NFD').replace(/[̀-ͯ]/g, ''); };
    var run = function () {
      var words = norm(state.q.toLowerCase()).split(/\s+/).filter(Boolean), visible = 0;
      cards.forEach(function (c) {
        var hay = norm(c.dataset.search);
        var ok = (!state.cat || c.dataset.cat === state.cat) &&
          (!state.g || (state.g === 'promo' ? c.dataset.promo === '1' : (c.dataset.gender === state.g || c.dataset.gender === 'unisex'))) &&
          words.every(function (w) { return hay.indexOf(w) > -1; });
        c.classList.toggle('is-filtered', !ok); if (ok) visible++;
      });
      cards.slice().sort(function (a, b) {
        return state.sort === 'low' ? a.dataset.price - b.dataset.price : state.sort === 'high' ? b.dataset.price - a.dataset.price : a.dataset.i - b.dataset.i;
      }).forEach(function (c) { grid.appendChild(c); });
      count.textContent = visible; none.hidden = visible > 0;
      grid._pager.reset();
      $$('[data-item]:not(.is-filtered):not(.is-paged)', grid).forEach(function (c, i) { c.classList.remove('just-shown'); void c.offsetWidth; c.style.setProperty('--k', Math.min(i, 8)); c.classList.add('just-shown', 'in'); });
    };
    initDD($('#catDD'), function (val) { state.cat = val; run(); });
    initDD($('#sortDD'), function (val) { state.sort = val; run(); });
    $$('#genderSeg button').forEach(function (b) {
      b.addEventListener('click', function () { $$('#genderSeg button').forEach(function (x) { x.classList.remove('on'); }); b.classList.add('on'); state.g = b.dataset.g; run(); });
    });
    var tm; qi.addEventListener('input', function () { clear.hidden = !qi.value; clearTimeout(tm); tm = setTimeout(function () { state.q = qi.value; run(); }, 160); });
    clear.addEventListener('click', function () { qi.value = ''; clear.hidden = true; state.q = ''; run(); qi.focus(); });
    $('#resetFilters').addEventListener('click', function () { qi.value = ''; clear.hidden = true; state.q = ''; $('#catDD .dd-menu button').click(); $('#genderSeg button').click(); });
    if (state.cat) { var b0 = $('#catDD [data-value="' + state.cat + '"]'); if (b0) b0.click(); else run(); } else run();
    if (params.get('focus')) setTimeout(function () { qi.focus(); }, introDone ? 100 : 2600);
  }

  if (page === 'gallery') {
    var m = $('#masonry'), pins = $$('.pin', m), lb = $('#lightbox'), lbImg = $('img', lb), lbCap = $('figcaption', lb), lbOrder = $('.lb-order', lb), list = [], idx = 0;
    var animate = function () { $$('.pin:not(.is-filtered):not(.is-paged)', m).forEach(function (p, i) { p.classList.remove('pin-in'); void p.offsetWidth; p.style.setProperty('--k', Math.min(i, 10)); p.classList.add('pin-in'); }); };
    $$('#galPills .pill').forEach(function (p) {
      p.addEventListener('click', function () {
        $$('#galPills .pill').forEach(function (x) { x.classList.remove('on'); }); p.classList.add('on');
        pins.forEach(function (pin) { pin.classList.toggle('is-filtered', !!p.dataset.f && pin.dataset.cat !== p.dataset.f); });
        m._pager.reset(); animate();
      });
    });
    animate();
    $('.more-btn').addEventListener('click', function () { setTimeout(function () { $$('.pin.just-shown', m).forEach(function (p) { p.classList.remove('just-shown', 'pin-in'); void p.offsetWidth; p.classList.add('pin-in'); }); }, 0); });
    var show = function (i) {
      idx = (i + list.length) % list.length; var p = list[idx], im = $('img', p);
      lbImg.style.opacity = 0;
      setTimeout(function () { lbImg.src = im.src; lbCap.textContent = im.alt; lbImg.style.opacity = 1; }, 150);
      lbOrder.href = p.dataset.id ? url(PAGES.order, { id: p.dataset.id }) : 'https://wa.me/' + S.whatsapp + '?text=' + encodeURIComponent(W.mWant + ' ' + im.alt + '\n' + im.src);
      lbOrder.target = p.dataset.id ? '' : '_blank';
    };
    m.addEventListener('click', function (e) {
      var pin = e.target.closest('.pin'); if (!pin) return;
      list = pins.filter(function (p) { return !p.classList.contains('is-filtered'); });
      lb.hidden = false; document.body.style.overflow = 'hidden';
      requestAnimationFrame(function () { lb.classList.add('open'); }); show(list.indexOf(pin));
    });
    var close = function () { lb.classList.remove('open'); document.body.style.overflow = ''; setTimeout(function () { lb.hidden = true; }, 350); };
    $('.lb-x', lb).addEventListener('click', close);
    lb.addEventListener('click', function (e) { if (e.target === lb || e.target.tagName === 'FIGURE') close(); });
    $('.prev', lb).addEventListener('click', function () { show(idx - 1); });
    $('.next', lb).addEventListener('click', function () { show(idx + 1); });
    document.addEventListener('keydown', function (e) { if (lb.hidden) return; if (e.key === 'ArrowLeft') show(idx - 1); if (e.key === 'ArrowRight') show(idx + 1); if (e.key === 'Escape') close(); });
    var sx = 0;
    lb.addEventListener('touchstart', function (e) { sx = e.touches[0].clientX; }, { passive: true });
    lb.addEventListener('touchend', function (e) { var d = e.changedTouches[0].clientX - sx; if (Math.abs(d) > 50) show(idx + (d < 0 ? 1 : -1)); });
  }

  if (page === 'order') {
    var qty = $('#qty'), total = $('#total'), picked = $('#picked'), current = null;
    var calc = function () { qty.value = Math.max(1, Math.min(50, +qty.value || 1)); total.textContent = current ? money(current.price * qty.value) : '—'; };
    var choose = function (p, animate) {
      current = p; var c = cat(p.cat);
      $('#pid').value = p.id; $('#pImg').src = p.img; $('#pName').textContent = L(p); $('#pCat').textContent = c ? L(c) : '';
      $('#pPrice').textContent = money(p.price); $('#pickLabel').textContent = W.change;
      $('#sizeField').hidden = !p.sizes; $('#f-size').placeholder = p.sizes || '';
      picked.classList.remove('is-empty', 'invalid', 'flash'); if (animate) { void picked.offsetWidth; picked.classList.add('flash'); }
      calc();
    };
    $$('.stepper button').forEach(function (b) { b.addEventListener('click', function () { qty.value = (+qty.value || 1) + (+b.dataset.step); calc(); }); });
    qty.addEventListener('input', calc);
    $$('.pick').forEach(function (b) {
      b.addEventListener('click', function () {
        choose(prod(b.dataset.id), true);
        try { history.replaceState(null, '', url(PAGES.order, { id: b.dataset.id })); } catch (e) {}
        closeSheets();
      });
    });
    var pq = $('#pickQ');
    pq.addEventListener('input', function () { var s = pq.value.toLowerCase(); $$('.pick').forEach(function (b) { b.hidden = b.dataset.search.indexOf(s) < 0; }); });
    var pre = prod(params.get('id'));
    if (pre) choose(pre, false); else setTimeout(function () { openSheet('pickerSheet'); }, introDone ? 500 : 2600);
    calc();
  }

  if (page === 'book') {
    initDD($('#serviceDD'), function (val) { $('#serviceVal').value = val; });
    var preB = $('#serviceDD [data-id="' + params.get('id') + '"]'); if (preB) preB.click();
  }
})();
